package Factory;

public interface IFactory {
    Student createstudent();
}
