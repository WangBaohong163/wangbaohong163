package Factory;

public class UndergraduateFactory implements IFactory {
    @Override
    public Student createstudent() {

        return new Undergraduate();
    }
}
