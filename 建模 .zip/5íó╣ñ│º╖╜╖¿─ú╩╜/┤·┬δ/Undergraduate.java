package Factory;

public class Undergraduate extends Student {
}
