package Factory;

public class Student {
    public void a() {
        System.out.println("听课");
    }

    public void b() {
        System.out.println("复习");
    }

    public void c() {
        System.out.println("考试");
    }
}
