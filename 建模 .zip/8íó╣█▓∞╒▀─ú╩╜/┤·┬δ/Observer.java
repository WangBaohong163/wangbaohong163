package guanchazhe;

public interface Observer {
     //更新
     public void update();
 }