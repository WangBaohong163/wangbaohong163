package decorator;

public class Necklace extends Chuanda{
    public void show() {
        super.show();
        System.out.println("项链");
    }
}
