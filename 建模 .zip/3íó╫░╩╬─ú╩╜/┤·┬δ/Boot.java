package decorator;

public class Boot extends Chuanda{
    public void show() {
        super.show();
        System.out.println("靴子");
    }
}
