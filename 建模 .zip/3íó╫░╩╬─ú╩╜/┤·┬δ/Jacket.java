package decorator;

public class Jacket extends Chuanda{
    public void show() {
        super.show();
        System.out.println("羽绒滑雪衫");
    }
}
