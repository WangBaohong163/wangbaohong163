package decorator;

public class Necktie extends Chuanda {
    public void show() {
        super.show();
        System.out.println("领带");
    }
}
