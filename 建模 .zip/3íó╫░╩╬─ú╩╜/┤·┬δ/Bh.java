package decorator;

public class bh {
    public static void main(String[] args) {
        Person person1 = new Person("成功人士");
        Xizhuang xizhuang =new Xizhuang();
        Necktie necktie = new Necktie();
        Watches watches = new Watches();
        Pixie pixie =new Pixie();
        xizhuang.decorate(person1);
        necktie.decorate(xizhuang);
        watches.decorate(necktie);
        pixie.decorate(watches);
        pixie.show();
        Person person2 =new Person("土豪");
        Necklace necklace =new Necklace();
        Phone phone =new Phone();
        necklace.decorate(person2);
        phone.decorate(necklace);
        phone.show();
        Person person3= new Person("学生");
        Jacket jacket =new Jacket();
        Trousers trousers =new Trousers();
        Boot boot =new Boot();
        jacket.decorate(person3);
        trousers.decorate(jacket);
        boot.decorate(trousers);
        boot.show();
    }
}
