package decorator;

public class Pixie extends Chuanda {
    public void show() {
        super.show();
        System.out.println("锃亮的皮鞋");
    }
}
