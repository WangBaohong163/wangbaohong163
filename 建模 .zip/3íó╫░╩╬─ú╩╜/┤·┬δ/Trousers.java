package decorator;

public class Trousers extends Chuanda{
    public void show() {
        super.show();
        System.out.println("裤子");
    }
}
