package decorator;

public class Phone extends Chuanda {
    public void show() {
        super.show();
        System.out.println("苹果11");
    }
}
