package decorator;

public class Watches extends Chuanda{
    public void show() {
        super.show();
        System.out.println("戴劳力士");
    }
}
