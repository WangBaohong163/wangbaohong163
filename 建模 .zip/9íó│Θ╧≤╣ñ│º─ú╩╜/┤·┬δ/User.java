//用户类假设只有ID和Name两个字段，其余省略。
public class User
{
    private int		id;
    private String	name;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

