package prototype;

public class ckd {
    public static void main(String[] args) {
        Resume a = new  Resume("丽华);
        a.setPersonalInfo("26","女");
        a.setWorkExperience("3年","腾讯");
        Resume b = a.clone("凯迪");
        b.setWorkExperience("2年半","阿里");
        Resume c = a.clone("小莉萨");
        c.setPersonalInfo("25","女");
        a.display();
        b.display();
        c.display();
    }
}
