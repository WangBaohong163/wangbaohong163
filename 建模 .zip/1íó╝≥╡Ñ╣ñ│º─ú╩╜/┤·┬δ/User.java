package easyfactory;

public class User{
    public static void main(String[] arge){
        Operation oper=null;
        //此处可以更改为其他运算符 而其他地方可以保持不变
        String op="-";
        oper=OperationFactory.createOperation(op);
        oper.setNumberA(99);
        oper.setNumberB(97);
        System.out.println(oper.getResult());
    }
}
