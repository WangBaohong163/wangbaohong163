package easyfactory;

public class Mul extends Operation {
    public double getResult() {
        return this.getNumberA()*this.getNumberB();
    }
}
