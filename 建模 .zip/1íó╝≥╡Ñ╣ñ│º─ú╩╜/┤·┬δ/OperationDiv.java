package easy;

public class OperationDiv  extends Operation {
    public double getResult() {
        if(this.getNumberB==0){
            System.out.println("除数不能为0");
            return 0;
        }
        return this.getNumberA()/this.getNumberB();
    }
}
