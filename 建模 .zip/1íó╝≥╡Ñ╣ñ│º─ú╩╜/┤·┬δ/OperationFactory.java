package easyfactory;

public class OperationFactory {
    public static Operation createOperation(String op){
        Operation ope =null;
        //判断并且确认将返回的对象
        switch (op){
            case "+":
                    operation=new OperationAdd();
                    break;
            case "-":
                    operation=new OperationSub();
                    break;
            case "*":
                    operation=new OperationMul();
                    break;
            case "/":
                    operation=new OperationDiv();
                    break;
            default:
                   break;
        }
        return operation;
    }
}
