package easyfactory;

public class Sub extends Operation {
    //重写父类方法
    public double getResult() {
        return this.getNumberA()-this.getNumberB();
    }
}
