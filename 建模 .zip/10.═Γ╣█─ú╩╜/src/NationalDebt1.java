public class NationalDebt1
{
    public void sell()
    {
        System.out.println("国债1卖出");
    }

    public void buy()
    {
        System.out.println("国债1买入");
    }
}