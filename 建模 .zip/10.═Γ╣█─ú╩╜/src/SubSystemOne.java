public class SubSystemOne
{
    public void methodOne()
    {
        System.out.println("子系统方法1");
    }
}