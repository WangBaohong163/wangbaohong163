public class SubSystemFour
{
    public void methodFour()
    {
        System.out.println("子系统方法4");
    }
}